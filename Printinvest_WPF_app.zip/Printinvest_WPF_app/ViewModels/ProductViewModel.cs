﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Printinvest_WPF_app.ViewModels
{
    internal class ProductViewModel
    {
    }
}
